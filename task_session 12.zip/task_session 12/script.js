var title=document.querySelector("input[name='title']")
var price=document.querySelector("input[name='price']")
var category=document.querySelector("input[name='category']")
var quantity=document.querySelector("input[name='quantity']")
var submit=document.querySelector("input[type='submit']")
var tbody = document.querySelector("#tbody")
var delete_all = document.querySelector("#delete_all")
var inputs= document.querySelectorAll("input:not(input[type='submit'])")
var data;
var sub ="create"

function check(){
if(localStorage.product !=null){
  data=JSON.parse(localStorage.product)
  delete_all.innerHTML = `<input onclick="Delete()" type="submit" value="Delete all"> `
}else{
   data=[] 
   delete_all.innerHTML =''
   
}
}
check()
submit.addEventListener('click',(e)=>{
    e.preventDefault()
    var error=false;
    inputs.forEach((input) => {
        if(input.value==''){
            alert(`${input.name} are required`);
            error=true
        }
    });
    if(error==false)
    {
    var newdata= {
        title : title.value,
        price : price.value,
        quantity : quantity.value,
        category : category.value,
    }
    if(sub=="create"){ 
    data.push(newdata)
    }else{
        data[ind]=newdata
        submit.value="Create"
        sub="create"
        
    }
    localStorage.setItem("product",JSON.stringify(data))
    showall()
     check()
     reset()
    
    }
})

function showall(){
    row =''
    for (let i = 0; i < data.length; i++){
        row+=`<tr>
        <td>${i+1}</td>
        <td>${data[i].title}</td>
        <td>${data[i].price}</td>
        <td>${data[i].category}</td>
        <td>${data[i].quantity}</td>
        <td><button id="update" onclick="update(${i})">Update</button></td>
        <td><button id="delete" onclick="delete_item(${i})">Delete</button></td>
    </tr>`
    }
    tbody.innerHTML=row
}

function Delete(){
 localStorage.clear()
 data.splice(0)
 check(); 
 showall();
}

function update(i){
 title.value=data[i].title
 price.value=data[i].price
 category.value=data[i].category
 quantity.value=data[i].quantity
 submit.value="Update"
 sub="update"
 ind=i
}
function delete_item(i){
 data.splice(i,1)
 localStorage.setItem("product",JSON.stringify(data))
    showall()
}

function reset(){
    title.value =''
    price.value =''
    category.value =''
    quantity.value =''
}